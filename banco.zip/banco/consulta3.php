<?php
session_start();
include 'conexion3.php';
if (!isset($_SESSION['usuario_logueado']) && $_SESSION['usuario_logueado'] !== true&&$_SESSION['tipo']!=='cajero') {
    header('Location:login2.php');
    exit();
}
$cliente=null;
$cuenta=null;
$error='';
$transacciones=[];
$tipo_usuario='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $cedula = trim($_POST['cedula']??'');
    if(empty($cedula)){
        $error = "ingrese una cedula";
    }else{
        $sql="SELECT * FROM usuarios WHERE ced_usu = ?";
        $stm = $conn->prepare($sql);
        $stm->bind_param("s", $cedula);
        $stm->execute();
        $resultado = $stm->get_result();
        if($resultado->num_rows===1){
            $cliente = $resultado ->fetch_assoc();
            $tipo_usuario = $cliente['tip_usu'];
            if($tipo_usuario==='cajero'){
                $cuenta = null;
                $transacciones = [];
            }else{
                $sql="SELECT num_cue, saldo FROM cuentas WHERE ced_cli_per = ?";
                $stm = $conn->prepare($sql);
                $stm -> bind_param("s",$cedula);
                $stm -> execute();
                $cuenta = $stm -> get_result()->fetch_assoc();
                if($cuenta){
                    $sql="SELECT tip_tra, monto, fec_tra FROM transacciones WHERE num_cue_per = ? ORDER BY fec_tra DESC";
                    $stm = $conn-> prepare($sql);
                    $stm -> bind_param("s",$cuenta['num_cue']);
                    $stm->execute();
                    $transacciones = $stm->get_result()->fetch_all(MYSQLI_ASSOC);
                }
            }
        }else{
            $error = "cliente no encontrado";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar</title>
</head>
<body>
    <h2>Buscar por cedula</h2>
    <form method="POST">
        <label for="">cedula</label>
        <input type="text" name="cedula" required>
        <button type="submit">BUSCAR</button>
        <?php if($cliente): ?>
            <hr>
            <h3>Datos cliente</h3>
            <p>Cedula <?= htmlspecialchars($cliente['ced_usu']) ?></p>
            <p>Nombre <?= htmlspecialchars($cliente['nom_usu']) ?></p>
            <?php if($tipo_usuario==='cajero'): ?>
                <p>Este es un cajero no tiene cuenta</p>
            <?php elseif($tipo_usuario==='cliente'): ?>
            <p>Cuenta <?= htmlspecialchars($cuenta['num_cue']) ?></p>
            <p>Saldo <?= htmlspecialchars($cuenta['saldo']) ?></p>
            <h3>Transacciones</h3>
            <?php if(count($transacciones)>0): ?>
            <table border="1" cellpadding="5">
                <thead>
                    <th>tipo</th>
                    <th>monto</th>
                    <th>fecha</th>
                </thead>
                <tbody>
                    <?php foreach($transacciones as $t): ?>
                        <tr>
                            <td><?= htmlspecialchars($t['tip_tra']) ?></td>
                            <td><?= htmlspecialchars($t['monto']) ?></td>
                            <td><?= htmlspecialchars($t['fec_tra']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
                <p>No hay transacciones</p>
            <?php endif; ?>
            <?php endif; ?>
            <?php endif; ?>
                    <?php if ($error): ?>
            <p style="color:red"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <a href="index3.php">Regresar</a>
            
    </form>
</body>
</html>