<?php
session_start();
include 'conexion3.php';
if (!isset($_SESSION['usuario_logueado']) || $_SESSION['usuario_logueado'] !== true) {
    header('Location:login3.php');
    exit();
}
$nombre = $_SESSION['nombre'];
$tipo = $_SESSION['tipo'];


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inicio</title>
</head>

<body>
    <h2>Bienvenido <?= htmlspecialchars($nombre) ?></h2>
    <h3>Tipo <?= htmlspecialchars($tipo) ?></h3>
    <?php if ($tipo === 'cajero'): ?>
        <ul>
            <li><a href="registro3.php">Registrar Cliente</a></li>
            <li><a href="consulta3.php">consultar transacciones</a></li>
            <li><a href="logout.php">Cerrar sesion</a></li>
        </ul>
    <?php elseif ($tipo === 'cliente'): ?>
        <ul>
            <li><a href="transacciones3.php">transacciones</a></li>
            <li><a href="logout.php">Cerrar sesion</a></li>
        </ul>
    <?php endif; ?>
</body>

</html>