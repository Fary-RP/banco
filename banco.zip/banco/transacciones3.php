<?php
session_start();
include 'conexion3.php';
if (!isset($_SESSION['usuario_logueado']) || $_SESSION['usuario_logueado'] !== true || $_SESSION['tipo'] !== 'cliente') {
    header('Location:login3.php');
    exit();
}
$cedula = $_SESSION['cedula'];
$error = '';
$exito = '';
$sql = "SELECT num_cue FROM cuentas WHERE ced_cli_per = ?";
$stm = $conn->prepare($sql);
$stm->bind_param("s", $cedula);
$stm->execute();
$cuenta = $stm->get_result()->fetch_assoc();
if (!$cuenta) {
    die("La cuenta no existe");
}
$num_cue = $cuenta['num_cue'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = $_POST['tipo'];
    $monto = floatval($_POST['monto']);
    if ($monto <= 0) {
        $error = "El monto debe ser mayor a 0";
    } else {
        $sql = "INSERT INTO transacciones (num_cue_per,tip_tra,monto)VALUES(?,?,?)";
        $stm = $conn->prepare($sql);
        $stm->bind_param("sss", $num_cue, $tipo, $monto);
        if ($stm->execute()) {
            $exito = "Se ha registrado la transaccion";
        } else {
            $error = "fallo en la transaccion";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>transacciones</title>
</head>

<body>
    <h2>Transacciones</h2>
    <p>cuenta <?= htmlspecialchars($num_cue) ?></p>
    <form method="POST" id="tra">
        <label for="">Tipo de transaccion</label>
        <select name="tipo" id="">
            <option value="deposito">Depositar</option>
            <option value="retiro">Retirar</option>
        </select><br><br>
        <label for="">Monto</label>
        <input type="number" step="0.1" name="monto" required><br><br>
        <button type="submit">Realizar transaccion</button>
        <?php if ($error): ?>
            <p style="color:red"><?= $error ?></p>
        <?php elseif ($exito): ?>
            <p style="color: green;"><?= $exito ?></p>
        <?php endif; ?>
        <a href="index3.php">Regresar</a>
    </form>
</body>

</html>