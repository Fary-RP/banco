<?php
$host = 'localhost';
$usuario = 'root';
$password = '';
$db = "banco_ta";
$conn = new mysqli($host,$usuario,$password,$db);
if ($conn-> connect_error){
    die("Sin conexion");
}
?>