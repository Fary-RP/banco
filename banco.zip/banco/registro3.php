<?php
session_start();
include 'conexion3.php';
if (!isset($_SESSION['usuario_logueado']) || $_SESSION['usuario_logueado'] !== true || $_SESSION['tipo'] !== 'cajero') {
    header('Location:login3.php');
    exit();
}
$error = '';
$exito = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $cedula = trim($_POST['cedula'] ?? '');
    $password = trim($_POST['password'] ?? '');
    if (empty($nombre) || empty($cedula) || empty($password)) {
        $error = "Llenar todos los campos";
    } else {
        $sql = "INSERT INTO usuarios (ced_usu,nom_usu,con_usu,tip_usu) VALUES (?,?,?,'cliente')";
        $stm = $conn->prepare($sql);
        $stm->bind_param("sss", $cedula, $nombre, $password);

        if ($stm->execute()) {
            $exito = "cliente ingresado con exito";
        } else {
            $error = "error al ingresar cliente verifique la informacion enviada";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>registro</title>
</head>

<body>
    <h2>Registro de Usuario</h2>
    <form method="POST" id="registro">
        <label for="">Nombre</label>
        <input type="text" name="nombre" id="nombre" required>
        <label for="">Cedula</label>
        <input type="text" name="cedula" id="cedula" maxlength="10" required>
        <label for="">Contraseña</label>
        <input type="password" name="password" required>
        <button type="submit">Registrar</button><br>
        <a href="index3.php">regresar</a>
    <?php if($exito): ?>
        <p style="color:green"><?= htmlspecialchars($exito) ?></p>
    <?php elseif($error): ?>
        <p style="color:red"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    </form>
    <script>
        document.getElementById('registro').onsubmit = function(e) {
            const nombre = document.getElementById('nombre').value.trim();
            const cedula = document.getElementById('cedula').value.trim();
            if(!nombre.trim()||/^\d/.test(nombre)){
                e.preventDefault();
                alert('Solo letras');
                return false;
            }
            if (!/^\d+$/.test(cedula)) {
                e.preventDefault();
                alert('Solo numeros');
                return false;
            }
            if (cedula.length !== 10) {
                e.preventDefault();
                alert('Ingrese 10 digitos');
                return false;
            }
            return true;
        }
    </script>
</body>

</html>