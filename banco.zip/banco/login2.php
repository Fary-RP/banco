<?php
session_start();
include 'conexion.php';
if(isset($_SESSION['usuario_logueado'])&&$_SESSION['usuario_logueado']===true){
    header('Location:index.php');
    exit();
}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $usuario = trim($_POST['usuario']??'');
    $password = trim($_POST['password']??'');
    if(empty($usuario)||empty($password)){
        $error="Llene ambos campos";
    }else{
        $sql="SELECT * FROM CLIENTES WHERE CED_USU =? AND CON_USU=?";
        $stm = $conn -> prepare($sql);
        $stm -> bind_param("ss",$usuario,$password);
        $stm -> execute();
        $resultado = $stm -> get_result();
        if($resultado->num_rows ===1){
            $fila = $resultado->fetch_assoc();
            $_SESSION['usuario_logueado']=true;
            $_SESSION['nombre']=$fila['nom_usu'];
            $_SESSION['cedula']=$fila['ced_usu'];
            $_SESSION['tipo']=$fila['tip_usu'];
            header('Location:index2.php');
            exit();
        }else{
            $error="Usuario o contraseña incorrectos";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Iniciar sesion</h2><br>
    <form method="POST" id="login">
        <label for="">Usuario(cedula)</label>
        <input type="text" name="usuario" id="cedula" maxlength="10" required> <br>
        <label for="">Contraseña</label>
        <input type="password" name="password"><br>
        <button type="submit">Ingresar</button>
        <?php if($error): ?>
            <p style="color: red;"> <?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
    </form>
    <script>
        document.getElementById('login').onsubmit=function(e){
            const cedula = document.getElementById('cedula').value.trim();
            if(!/^\d+$/.test(cedula)){
                e.preventDefault();
                alert('Solo numeros');
                return false;
            }
            if(cedula.length !== 10){
                e.preventDefault();
                alert('Ingrese 10 digitos');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>