<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['logueado']) || $_SESSION['logueado'] !== true || $_SESSION['tipo'] !== 'estudiante') {
    header('Location: index.php');
    exit();
}

$cedula = $_SESSION['cedula'];
$error = '';
$exito = '';

$sql = "SELECT COUNT(*) as total FROM respuestas WHERE cedula_estudiante = ?";
$stm = $conn->prepare($sql);
$stm->bind_param("s", $cedula);
$stm->execute();
$ya_respondio = $stm->get_result()->fetch_assoc()['total'] > 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$ya_respondio) {
    $respuestas = $_POST['respuestas'] ?? [];

    $sql = "SELECT id, texto FROM preguntas ORDER BY id";
    $stm = $conn->prepare($sql);
    $stm->execute();
    $preguntas = $stm->get_result()->fetch_all(MYSQLI_ASSOC);

    if (count($respuestas) === count($preguntas)) {
        $conn->begin_transaction();
        try {
            foreach ($preguntas as $i => $p) {
                $sql = "INSERT INTO respuestas (cedula_estudiante, pregunta_id, respuesta) VALUES (?, ?, ?)";
                $stm = $conn->prepare($sql);
                $stm->bind_param("sis", $cedula, $p['id'], $respuestas[$i]);
                $stm->execute();
            }
            $conn->commit();
            $exito = " ¡Gracias por responder la encuesta!";
            $ya_respondio = true;
        } catch (Exception $e) {
            $conn->rollback();
            $error = " Error al guardar: " . htmlspecialchars($e->getMessage());
        }
    } else {
        $error = "Complete todas las preguntas";
    }
}

// Cargar preguntas
$sql = "SELECT id, texto FROM preguntas ORDER BY id";
$stm = $conn->prepare($sql);
$stm->execute();
$preguntas = $stm->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Encuesta</title>
</head>
<body>
    <h2> Encuesta de Satisfacción</h2>

    <?php if ($ya_respondio): ?>
        <div class="success">
            <h3>¡Ya respondiste la encuesta!</h3>
            <p>Gracias por tu participación.</p>
        </div>
        <a href="index.php">← Volver al panel</a>
    <?php else: ?>
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php elseif ($exito): ?>
            <div class="success"><?= htmlspecialchars($exito) ?></div>
        <?php endif; ?>

        <form method="POST">
            <?php foreach ($preguntas as $i => $p): ?>
                <div class="form-group">
                    <label><?= $i+1 ?>. <?= htmlspecialchars($p['texto']) ?></label>
                    <input type="text" name="respuestas[<?= $i ?>]" maxlength="200" required>
                </div>
            <?php endforeach; ?>
            
            <button type="submit">Enviar respuestas</button>
            <a href="index.php" style="margin-left: 10px;">Cancelar</a>
        </form>
    <?php endif; ?>
</body>
</html>