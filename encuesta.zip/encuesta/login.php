<?php
session_start();
include 'conexion.php';

if (isset($_SESSION['logueado']) && $_SESSION['logueado'] === true) {
    header('Location: index.php');
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cedula = trim($_POST['cedula'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($cedula) || empty($password)) {
        $error = "Complete ambos campos";
    } else {
        $sql = "SELECT * FROM usuarios WHERE cedula = ? AND password = ?";
        $stm = $conn->prepare($sql);
        $stm->bind_param("ss", $cedula, $password);
        $stm->execute();
        $res = $stm->get_result();

        if ($res->num_rows === 1) {
            $fila = $res->fetch_assoc();
            $_SESSION['logueado'] = true;
            $_SESSION['cedula'] = $fila['cedula'];
            $_SESSION['nombre'] = $fila['nombre'];
            $_SESSION['tipo'] = $fila['tipo'];
            header('Location: index.php');
            exit();
        } else {
            $error = "Usuario o contraseña incorrectos";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - Encuesta</title>
</head>
<body>
    <h2> Iniciar Sesión</h2>
    
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" id="loginForm">
        <div class="form-group">
            <label>Cédula:</label>
            <input type="text" name="cedula" id="cedula" maxlength="10" required>
        </div>
        <div class="form-group">
            <label>Contraseña:</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit">Ingresar</button>
    </form>

    <script>
        document.getElementById('loginForm').onsubmit = function(e) {
            const cedula = document.getElementById('cedula').value.trim();
            if (!/^\d{10}$/.test(cedula)) {
                e.preventDefault();
                alert("La cédula debe tener 10 dígitos numéricos");
                return false;
            }
        };
    </script>
</body>
</html>