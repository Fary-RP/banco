<?php
session_start();
if (!isset($_SESSION['logueado']) || $_SESSION['logueado'] !== true) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Principal</title>

</head>
<body>
    <div class="card">
        <h2>👋 Bienvenido, <span style="color:#007bff"><?= htmlspecialchars($_SESSION['nombre']) ?></span>!</h2>
        <p><strong>Cédula:</strong> <?= htmlspecialchars($_SESSION['cedula']) ?></p>
        <p><strong>Tipo:</strong> 
            <span class="<?= $_SESSION['tipo'] === 'admin' ? 'role-admin' : 'role-estudiante' ?>">
                <?= htmlspecialchars($_SESSION['tipo']) ?>
            </span>
        </p>
    </div>

    <div class="card">
        <h3>Opciones disponibles</h3>
        <?php if ($_SESSION['tipo'] === 'estudiante'): ?>
            <a href="encuesta.php">Responder encuesta (una sola vez)</a>
        <?php elseif ($_SESSION['tipo'] === 'admin'): ?>
            <a href="resultados.php"> Ver resultados de la encuesta</a>
        <?php endif; ?>
        <a href="logout.php" style="background:#ffebee; color:#d63031;">🚪 Cerrar sesión</a>
    </div>
</body>
</html>