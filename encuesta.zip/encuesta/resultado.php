<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['logueado']) || $_SESSION['logueado'] !== true || $_SESSION['tipo'] !== 'admin') {
    header('Location: index.php');
    exit();
}

$sql = "
    SELECT u.cedula, u.nombre, p.texto, r.respuesta, r.fecha
    FROM respuestas r
    JOIN usuarios u ON r.cedula_estudiante = u.cedula
    JOIN preguntas p ON r.pregunta_id = p.id
    ORDER BY r.cedula_estudiante, p.id
";
$stm = $conn->prepare($sql);
$stm->execute();
$resultados = $stm->get_result()->fetch_all(MYSQLI_ASSOC);

$estudiantes = array_unique(array_column($resultados, 'cedula'));
$total_estudiantes = count($estudiantes);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultados</title>
</head>
<body>
    <h2>Resultados de la Encuesta</h2>
    
    <div class="stats">
        <h3>Estadísticas</h3>
        <p><strong>Total de estudiantes que respondieron:</strong> <?= $total_estudiantes ?></p>
        <p><strong>Total de respuestas:</strong> <?= count($resultados) ?></p>
    </div>

    <?php if ($resultados): ?>
        <table>
            <thead>
                <tr>
                    <th>Cédula</th>
                    <th>Nombre</th>
                    <th>Pregunta</th>
                    <th>Respuesta</th>
                    <th>Fecha</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($resultados as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['cedula']) ?></td>
                        <td><?= htmlspecialchars($r['nombre']) ?></td>
                        <td><?= htmlspecialchars($r['texto']) ?></td>
                        <td><?= htmlspecialchars($r['respuesta']) ?></td>
                        <td><?= htmlspecialchars($r['fecha']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="color: #6c757d;">No hay respuestas aún.</p>
    <?php endif; ?>

    <a href="index.php" class="back">← Volver al panel</a>
</body>
</html>